// Importa a biblioteca do Venom Bot
const venom = require('venom-bot');

// Importa a biblioteca do Puppeteer
const puppeteer = require('puppeteer');

// Importa as funções de processamento
const { process_text_gemini } = require("./proccess/proccess_text.js");
const { process_audio } = require("./proccess/proccess_audio.js");
const { process_image_gemini } = require("./proccess/proccess_image.js");

// Cria uma instância do Venom Bot com o nome da sessão "session-name" e opções do Puppeteer para rodar sem sandbox
venom.create({
  session: 'pedro-vale',
  puppeteerOptions: { args: ['--no-sandbox'] },
  headless: true
})
  .then((client) => start(client))  // Inicia o bot quando a instância for criada
  .catch((error) => { console.log(error); }); // Trata erros durante a criação da instância

// Função de inicialização do bot
function start(client) {
  // Inicia o Puppeteer sem sandbox
  puppeteer.launch({ args: ['--no-sandbox'] });

  // Escuta mensagens recebidas
  client.onMessage(async (message) => {
    // Verifica se a mensagem é uma mídia ou MMS
    if (message.isMedia === true || message.isMMS === true) {
      // Se for uma imagem, processa a imagem
      if (message.mimetype.startsWith('image/')) {
        const buffer = await client.decryptFile(message);
        const base64Image = buffer.toString('base64');
        process_image_gemini(message.caption, base64Image, message);
      } 
      // Se for um áudio, processa o áudio
      else if (message.mimetype === 'audio/mp4') {
        const buffer = await client.decryptFile(message);
        const base64Audio = buffer.toString('base64');
        process_audio(base64Audio);
      }
    } 
    // Se não for uma mídia, processa o texto
    else {
      process_text_gemini(message.body, message);
    }
  });
}