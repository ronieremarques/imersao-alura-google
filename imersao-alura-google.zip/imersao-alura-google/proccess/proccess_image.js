// Importa a biblioteca do Google Generative AI
const { GoogleGenerativeAI } = require("@google/generative-ai");

// Importa o módulo do sistema de arquivos
const fs = require("fs");

// Cria uma instância do Google Generative AI com a chave de API fornecida como uma variável de ambiente
const genAI = new GoogleGenerativeAI(process.env.API_KEY);

// Converte as informações do arquivo local em um objeto GoogleGenerativeAI.Part.
function fileToGenerativePart(path, mimeType) {
  return {
    inlineData: {
      data: Buffer.from(fs.readFileSync(path)).toString("base64"),
      mimeType,
    },
  };
}

// Função assíncrona para executar a geração de texto e imagem
async function process_image_gemini(caption, base64Image, message) {
  // Para entrada de texto e imagem (multimodal), use o modelo gemini-pro-vision
  const model = genAI.getGenerativeModel({ model: "gemini-pro-vision" });

  const prompt = "What's different between these pictures?";

  // Cria um array de objetos GoogleGenerativeAI.Part para as imagens
  const imageParts = [
    fileToGenerativePart("image1.png", "image/png"),
    fileToGenerativePart("image2.jpeg", "image/jpeg"),
  ];

  // Gera o conteúdo usando o modelo e as imagens fornecidas
  const result = await model.generateContent([prompt, ...imageParts]);

  // Obtém a resposta da API
  const response = await result.response;

  // Obtém o texto gerado
  const text = response.text();

  // Envia o texto gerado de volta para o cliente
  message.send(text);
}